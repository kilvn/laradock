/*
  +----------------------------------------------------------------------+
  | XlsWriter Extension                                                  |
  +----------------------------------------------------------------------+
  | Copyright (c) 2017-2018 The Viest                                    |
  +----------------------------------------------------------------------+
  | http://www.viest.me                                                  |
  +----------------------------------------------------------------------+
  | Author: viest <dev@service.viest.me>                                 |
  +----------------------------------------------------------------------+
*/

#ifndef PHP_EXT_XLS_WRITER_COMMON_H
#define PHP_EXT_XLS_WRITER_COMMON_H

#ifdef PHP_WIN32
#	define PHP_VTIFUL_API __declspec(dllexport)
#elif defined(__GNUC__) && __GNUC__ >= 4
#	define PHP_VTIFUL_API __attribute__ ((visibility("default")))
#else
#	define PHP_VTIFUL_API
#endif

#ifdef ZTS
#include "TSRM.h"
#endif

#if PHP_VERSION_ID >= 80000
#define TSRMLS_D	void
#define TSRMLS_DC
#define TSRMLS_C
#define TSRMLS_CC
#endif

#define VTIFUL_RESOURCE_NAME "xlsx"

#define VTIFUL_STARTUP_MODULE(module) ZEND_MODULE_STARTUP_N(xlsxwriter_##module)(INIT_FUNC_ARGS_PASSTHRU)
#define VTIFUL_STARTUP_FUNCTION(module) ZEND_MINIT_FUNCTION(xlsxwriter_##module)

#if defined(ZTS) && defined(COMPILE_DL_VTIFUL)
ZEND_TSRMLS_CACHE_EXTERN();
#endif

#endif
